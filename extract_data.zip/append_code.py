import glob
import os
import pickle
import shutil
import subprocess

import pandas
import pandas as pd
from gensim import corpora, similarities
from gensim.models import LdaModel, LsiModel, TfidfModel
from gensim.models.doc2vec import TaggedDocument
from gensim.parsing import preprocess_string, remove_stopwords
from git import Repo

prjs = [
    {
        "project": 'Hadoop Common',
        "project_path_name": 'hadoop-common'
    },
    {
        "project": 'Hadoop HDFS',
        "project_path_name": 'hadoop-hdfs'
    },
    {
        "project": 'Hadoop Map/Reduce',
        "project_path_name": 'hadoop-mapreduce'
    },
    {
        "project": 'OFBiz',
        "project_path_name": 'ofbiz'
    },
    {
       "project": 'Camel',
       "project_path_name": 'camel'
    },
    {
        "project": 'ZooKeeper',
        "project_path_name": 'zookeeper'
    },
    {
        "project": 'HBase',
        "project_path_name": 'hbase'
    },
    {
        "project": 'Hive',
        "project_path_name": 'hive'
    },
    {
        "project": 'Hibernate ORM',
        "project_path_name": 'hibernate-orm'
    },
    {
        "project": 'Cassandra',
        "project_path_name": 'cassandra'
    },
    {
        "project": 'Harmony',
        "project_path_name": 'harmony'
    },
    {
        "project": 'Wicket',
        "project_path_name": 'wicket'
    }
]


def process_documents(data):
    documents = list()
    docs = {}
    for i, line in data[['key', 'title', 'comments', 'desc']].iterrows():
        comments = '' if line['comments'] != line['comments'] else ''.join(line['comments'].split('@!NEXT!@'))
        desc = '' if line['desc'] != line['desc'] else line['desc']
        title = '' if line['title'] != line['title'] else line['title']
        txt = preprocess_string((remove_stopwords(title + desc)))
        if txt == '':
            print(line['key'] + ' is empty')
        docs[line['key']] = txt
        documents.append(TaggedDocument(txt, [line['key']]))
    return docs, documents

def dump_k_lda(corpus_path, model_path, sim_result_path, data, type,k):
    # if os.access(sim_result_path, os.F_OK):
    #     return
    print(sim_result_path)
    lsi_corpus_path_arr = corpus_path.split('.pk')
    lsi_corpus_path = lsi_corpus_path_arr[0]+'_lsi.pk'
    lsi_corpus_dict_path = lsi_corpus_path_arr[0]+'_dict_lsi.pk'
    lsi_corpus_tfidf_path = lsi_corpus_path_arr[0]+'_tfidf_lsi.pk'
    lsi_corpus_tags_path = lsi_corpus_path_arr[0]+'_tags_lsi.pk'

    stopwords = 'hadoop,org,apach,java,mapr,hdf,map,reduc,ofbiz,camel,zookeep,server,hbase,hive,hibern,cassandra,wicket'.split(',')
    stopwords.extend(['common', 'log', 'lang', 'junit', 'tasktrack', 'block', 'method', 'datanod', 'user', 'code', 'error', 'namenod', 'test', 'job', 'fail', 'info', 'task', 'run', 'df', 'file'])
    stopwords.extend(['thread', 'user', 'log', 'client', 'dfsclient', 'error', 'data', 'code', 'run', 'dir', 'df', 'fail', 'datanod', 'clitesthelp', 'cli', 'block', 'test', 'file', 'info', 'namenod'])
    stopwords.extend(['tasktrack', 'jar', 'lang', 'secur', 'junit', 'attempt', 'log', 'method', 'user', 'error', 'code', 'test', 'yarn', 'file', 'info', 'fail', 'run', 'task', 'mapreduc', 'job'])
    stopwords.extend(['except', 'string', 'modelscreenwidget', 'control', 'null', 'product', 'entiti', 'webapp', 'creat', 'widget', 'catalina', 'xml', 'core', 'lang', 'screen', 'http', 'invok', 'order', 'error', 'servic'])
    stopwords.extend(['except', 'test', 'run', 'xml', 'messag', 'springframework', 'exchang', 'http', 'impl', 'rout', 'cxf', 'com', 'thread', 'info', 'code', 'util', 'file', 'compon', 'processor', 'process'])
    stopwords.extend(['nioservercnxn', 'src', 'state', 'close', 'node', 'code', 'quorump', 'error', 'thread', 'session', 'fail', 'quorum', 'follow', 'run', 'log', 'leader', 'connect', 'info', 'test', 'client'])
    stopwords.extend(['meta', 'fail', 'method', 'sun', 'util', 'hregion', 'lang', 'log', 'test', 'tabl', 'thread', 'ipc', 'run', 'client', 'debug', 'code', 'info', 'master', 'regionserv', 'region'])
    stopwords.extend(['type', 'job', 'column', 'oper', 'creat', 'null', 'kei', 'file', 'queri', 'run', 'error', 'fail', 'code', 'string', 'exec', 'junit', 'partit', 'select', 'test', 'tabl'])
    stopwords.extend(['tabl', 'column', 'type', 'public', 'null', 'cascad', 'return', 'code', 'invok', 'com', 'cfg', 'test', 'debug', 'info', 'queri', 'collect', 'main', 'entiti', 'class', 'loader'])
    stopwords.extend(['tabl', 'keyspac', 'thrift', 'rangetombstonelist', 'error', 'lib', 'compact', 'test', 'kei', 'lang', 'column', 'line', 'node', 'threadpoolexecutor', 'info', 'thread', 'concurr', 'run', 'util', 'data'])
    stopwords.extend(['drlvm', 'fail', 'run', 'classlib', 'throw', 'cpp', 'void', 'string', 'main', 'method', 'new', 'thread', 'public', 'class', 'lang', 'harmoni', 'txtad', 'kjv', 'luindex', 'test'])
    stopwords.extend(['string', 'util', 'error', 'line', 'markupcontain', 'work', 'method', 'jetti', 'class', 'ajax', 'html', 'markup', 'new', 'requestcycl', 'request', 'http', 'form', 'compon', 'page', 'wicket'])

    try:
        with open(corpus_path, 'rb') as f1:
            docs = pickle.load(f1)
        with open(lsi_corpus_path,'rb') as f2:
            corpus = pickle.load(f2)
        with open(lsi_corpus_tags_path, 'rb') as f4:
            doc_tags = pickle.load(f4)
        with open(lsi_corpus_dict_path,'rb') as f3:
            dictionary = pickle.load(f3)
    except:
        docs, documents = process_documents(data)
        corpus = list()
        doc_tags = list()
        for doc_tag, doc_corpus in docs.items():
            doc_tags.append(doc_tag)
            corpus.append(doc_corpus)
        dictionary = corpora.Dictionary(corpus)
        corpus = [dictionary.doc2bow(line) for line in corpus]

        with open(corpus_path, 'wb') as f1:
            pickle.dump(docs, f1)
        with open(lsi_corpus_path,'wb') as f2:
            pickle.dump(corpus, f2)
        with open(lsi_corpus_dict_path,'wb') as f3:
            pickle.dump(dictionary, f3)
        with open(lsi_corpus_tags_path, 'wb') as f4:
            pickle.dump(doc_tags, f4)

    # if not os.access(lsi_corpus_tfidf_path, os.F_OK):
    #     tfidf = TfidfModel(dictionary=dictionary)
    #     tfidf.save(lsi_corpus_tfidf_path)
    # else:
    #     tfidf = TfidfModel.load(lsi_corpus_tfidf_path)
    # corpus_tfidf = tfidf[corpus]

    texts = []
    corpus_new = []
    dct = {}
    for doc_tag, doc_corpus in docs.items():
        # doc_tags.append(doc_tag)
        tmp = []
        for term in doc_corpus:
            if dct.get(term) is None: dct[term]=0
            if term in stopwords:continue
            dct[term]+=1
            tmp.append(term)
        texts.append(tmp)
    # res = [k for k,v in list(sorted(dct.items(), key = lambda kv:(kv[1], kv[0]))) [-20:]]
    # print(res)
    corpus = [dictionary.doc2bow(text) for text in texts]
    if not os.access(model_path,os.F_OK):
        print('generating lda model for '+corpus_path)
        # num, model = coherence_values_computation(dictionary, corpus, texts, 10)
        # print(str(num) + ' '+ corpus_path)
        model = LdaModel(corpus, num_topics=k, id2word=dictionary)
        model.save(model_path)
    model = LdaModel.load(model_path)
    print(model.print_topics())
    arr = []
    j = 0
    for doc_tag, doc_corpus in docs.items():
        tmp = {}
        for (i, proba) in model.get_document_topics(corpus[j]):
            tmp['Topic_'+str(i)] = proba
        tmp['key']=doc_tag
        arr.append(tmp)
        j+=1
    pd.DataFrame(arr).to_csv(sim_result_path, index = False)

    # simres = gen_sim_res(docs, data, model, type,lsi_corpus_path,lsi_corpus_dict_path,lsi_corpus_tags_path,k)
    # pd.DataFrame(simres).to_csv(sim_result_path)
    # with open(sim_result_path,'wb') as f2:
    #     pickle.dump(simres, f2)
    # return simres


def gen_corpus(project_dir, output_dir):
    result_corpus = []
    for java_file in glob.glob(project_dir+'\\**\*.java',recursive=True):
        try:
            with open(java_file, 'r', encoding='utf-8') as f1:
                content = f1.read()
        except:
            with open(java_file, 'r', encoding='ISO-8859-1') as f1:
                content = f1.read()
        try:
            content = content.split('*/')[1]
        except:
            content = content.split('*/')[-1]
        filename = java_file.split('\\')[-1].replace('.java', '')
        txt = preprocess_string((remove_stopwords(filename + ' ' + content)))
        result_corpus.append({'corpus': txt, 'file': java_file})
    if len(result_corpus)>0:
        pd.DataFrame(result_corpus).to_csv(output_dir+'corpus.csv', index=False)
    return result_corpus


def read_similarity(entity, prj, d, line):

    try:
        sim_df = pd.read_csv('z:\\data\\coderesult\\similarity_'+d+'.csv')
    except:
        print('similarity not found:'+'z:\\data\\coderesult\\similarity_'+d+'.csv')
        corpus = []
        desc = '' if line['desc'] != line['desc'] else line['desc']
        title = '' if line['title'] != line['title'] else line['title']
        txt = preprocess_string((remove_stopwords(title + desc)))

        try:
            corpus_entity = pd.read_csv('z:\\data\\corpus_data\\' + prj + '_' + entity + '_' + 'corpus.csv')
        except:
            print('missing corpus ' + 'z:\\data\\corpus_data\\' + prj + '_' + entity + '_' + 'corpus.csv')
            base_path = 'c:\\repo\\'
            project_dir = base_path + prj
            output_dir = 'z:\\data\\corpus_data\\' + prj + '_' + entity + '_'
            project_dir_copied = base_path + prj + '_' + str(os.getpid())
            if not os.access(project_dir_copied, os.F_OK):
                shutil.copytree(project_dir, project_dir_copied)
            gr = Repo(project_dir_copied).git
            gr.checkout(entity, force=True)
            print('checking out ' + entity + ' ' + prj)

            gen_corpus(project_dir_copied, output_dir)
            try:
                corpus_entity = pd.read_csv('z:\\data\\corpus_data\\' + prj + '_' + entity + '_' + 'corpus.csv')
            except:
                print(
                    'error generating corpus ' + 'z:\\data\\corpus_data\\' + prj + '_' + entity + '_' + 'corpus.csv')
                return
            # continue
        # metrics_entity = pd.read_csv('Z:\\data\\class_data\\'+prj+'_'+entity+'_'+'class.csv')
        for i, arr in corpus_entity.iterrows():
            corpus.append(eval(arr['corpus']))
        corpus.append(txt)
        tags = list(corpus_entity['file'])
        tags.append('txt')
        dictionary = corpora.Dictionary(corpus)
        corpus = [dictionary.doc2bow(line) for line in corpus]
        tfidf = TfidfModel(dictionary=dictionary)
        corpus_tfidf = tfidf[corpus]
        model = LsiModel(corpus_tfidf, num_topics=20, id2word=dictionary)

        vec_bow = dictionary.doc2bow(txt)
        vec_lsi = model[vec_bow]  # convert the query to LSI space
        index = similarities.MatrixSimilarity(model[corpus])
        sims = index[vec_lsi]
        sims = sorted(enumerate(sims), key=lambda item: -item[1])
        res = list()
        i = 0
        simres = []
        for sim in sims:
            (id_doc, val) = sim
            if tags[id_doc] == 'txt': continue
            i += 1
            # if i > 30: continue
            # if i > k: continue
            simres.append({'tags': tags[id_doc], 'val': val})
        sim_df = pd.DataFrame(simres)
        sim_df.to_csv('z:\\data\\coderesult\\similarity_' + d + '.csv', index=False)
    return sim_df

def match_file_name(file_name, arr_name):
    for i,name in enumerate(arr_name):
        if file_name == name:
            return i
    return None

def read_sim_and_line_one(sim_df, metrics_entity, d):
    skip = 0
    i=0
    sims = []
    lines = []
    for ii, row in sim_df.iterrows():
        i += 1
        try:
            idx = match_file_name(row['tags'],metrics_entity['file'])
        except:
            idx = None
        if idx is None:
            skip += 1
            continue
        else:
            me = metrics_entity.iloc[idx]
            return [row['val']],[me]

    # print(d + ' ' + str(skip) + '/' + str(i) + '|' + str(i - skip))
    return sims, lines


def find_entity(rep_time, hash_df, prj, d, line,hashes):
    date = rep_time[d]['updated_at']
    entity = hash_df[hash_df['date'] == str(date.year) + '/' + str(date.month) + '/' + str(date.day)].iloc[0]['hash']
    return entity


def generate_code_1(rep_time, hash_df, prj, d, line,k):
    print('generating '+d+' '+str(k))

    hashes = set()
    metrics_entity = []
    sims = None
    try:
        with open('z:\\data\\reporthash\\'+d+'.txt','r') as f0:
            entity = f0.read()
        metrics_entity = read_metrics_entity(entity, prj)
        sim_df = read_similarity(entity, prj, d, line)
        sims, lines = read_sim_and_line_one(sim_df, metrics_entity, d)

    except:
        entity = find_entity(rep_time, hash_df, prj, d, line, hashes)
        if entity is None : return
        newnum = int(d.split('-')[1])
        while len(metrics_entity)<10:
            metrics_entity = read_metrics_entity(entity, prj)
            if metrics_entity is None :
                metrics_entity=[]
                hashes.add(entity)
            sim_df = read_similarity(entity, prj, d, line)
            if sim_df is None: return
            sims, lines = read_sim_and_line_one(sim_df, metrics_entity, d)

        with open('z:\\data\\reporthash\\'+d+'.txt','w') as f2:
            f2.write(entity)

    heads = 'cbo,cboModified,fanin,fanout,wmc,dit,noc,rfc,lcom,lcom*,tcc,lcc,totalMethodsQty,staticMethodsQty,publicMethodsQty,privateMethodsQty,protectedMethodsQty,defaultMethodsQty,visibleMethodsQty,abstractMethodsQty,finalMethodsQty,synchronizedMethodsQty,totalFieldsQty,staticFieldsQty,publicFieldsQty,privateFieldsQty,protectedFieldsQty,defaultFieldsQty,finalFieldsQty,synchronizedFieldsQty,nosi,loc,returnQty,loopQty,comparisonsQty,tryCatchQty,parenthesizedExpsQty,stringLiteralsQty,numbersQty,assignmentsQty,mathOperationsQty,variablesQty,maxNestedBlocksQty,anonymousClassesQty,innerClassesQty,lambdasQty,uniqueWordsQty,modifiers,logStatementsQty'.split(',')
    tmp = {'key':d}
    for h in heads:
        tmp[h] = 0
    row = lines[0]
    for h in heads:
        if heads == 'tcc' and row[h]<0: row[h]=0 #value -1 is not applicable
        if heads == 'lcc' and row[h]<0: row[h]=0 #value -1 is not applicable
        if row[h]==-1: row[h]=0 #value -1 is not applicable

        tmp[h] = row[h] if row[h] == row[h] else 0
    # new_metrics.append(h)
    pd.DataFrame([tmp]).to_csv('z:\\data\\codemetricsresult_'+str(k)+'\\'+d+'.csv', index=False)



def read_metrics_entity(entity, prj):
    try:
        try:
            metrics_entity = pd.read_csv('Z:\\data\\class_data\\' + prj + '_' + entity + '_' + 'class.csv',encoding='UTF-8')
        except:
            metrics_entity = pd.read_csv('Z:\\data\\class_data\\' + prj + '_' + entity + '_' + 'class.csv',encoding='ISO-8859-1')

    except:
        ck_jar = 'E:\\tools\\ck-ck-0.7.0\\target\\ck-0.7.0-jar-with-dependencies.jar'
        base_path = 'C:\\repo\\'
        output_dir = 'Z:\\data\\class_data\\' + prj + '_' + entity + '_'
        project_dir = base_path + prj
        project_dir_copied = base_path + prj + '_' + str(os.getpid())
        if not os.access(project_dir_copied,os.F_OK):
            shutil.copytree(project_dir,project_dir_copied)
        try:
            gr = Repo(project_dir_copied).git
            gr.checkout(entity, force=True)
        except:
            return None
        cmd = ['java', '-jar', ck_jar, project_dir_copied, 'false', '0', 'True', output_dir]
        print(' '.join(cmd))
        subprocess.call(cmd)
        try:
            metrics_entity = pd.read_csv('Z:\\data\\class_data\\' + prj + '_' + entity + '_' + 'class.csv')
        except:
            return None
    return metrics_entity


def lda(k):
    input_list = []
    for prj in prjs:
        data_path = 'E:\\reports\\defect\\data_new_mean_' + prj['project_path_name'] +'.csv'
        model_path = 'H:\\reports\\defect2\\data_new_mean_' + prj['project_path_name'] + '_lda'+'_'+str(k)+'.model'
        corpus_path = 'H:\\reports\\defect2\\data_new_mean_' + prj['project_path_name'] +'_lsi_30.pk'
        topic_result_path = 'H:\\reports\\defect2\\data_topic_' + prj['project_path_name'] + '_'+str(k)+'.csv'
        data = pandas.read_csv(data_path)
        data = data[data['type']=='Bug']
        input_list.append([corpus_path, model_path, topic_result_path, data, 'lda', k])
        dump_k_lda(corpus_path, model_path, topic_result_path, data, type, k)
    # pool = multiprocessing.Pool(processes=12)
    # pool.starmap(dump_k_lda, input_list)
    
    
lda(10)

rep_time_path = 'E:\\reports\\defect\\rep_time.pk'
with open(rep_time_path, 'rb') as f3:
    rep_time = pickle.load(f3)

for project in prjs:
    prj = project['project_path_name']
    data = pandas.read_csv('E:\\reports\\defect\\data_10.csv') # the csv file in the codeocean replication package
    data = data[data['project_name'] == project['project']]

    hash_df = pd.read_csv('h:\\reports\\defect2\\date_hash_' + prj + '.csv')
    for idx, line in data.iterrows():
        d = line['key']
        generate_code_1(rep_time, hash_df, prj, d, line, 1)

