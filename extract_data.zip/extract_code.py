import json
import multiprocessing
import os
import pickle

import gensim.models
import pandas as pd
import shap
from datetime import datetime
from itertools import product
from statistics import variance
import seaborn as sns
import matplotlib.pyplot as plt
from gensim import corpora, similarities
from gensim.models import LdaMulticore, LsiModel, TfidfModel, Word2Vec
from krippendorff import krippendorff
from gensim.parsing import PorterStemmer, remove_stopwords, preprocess_string
from imblearn.ensemble import RUSBoostClassifier, EasyEnsembleClassifier, BalancedRandomForestClassifier, \
    BalancedBaggingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import minmax_scale, label_binarize
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
from AutoSpearman import AutoSpearman
# import xgboost as xgb
sns.set()
from imblearn.combine import SMOTEENN, SMOTETomek
from imblearn.over_sampling import SMOTE, RandomOverSampler, SMOTENC, SVMSMOTE, ADASYN, KMeansSMOTE, BorderlineSMOTE
from imblearn.under_sampling import RandomUnderSampler, ClusterCentroids, OneSidedSelection, CondensedNearestNeighbour, \
    EditedNearestNeighbours, RepeatedEditedNearestNeighbours, AllKNN, InstanceHardnessThreshold, TomekLinks, \
    NeighbourhoodCleaningRule, NearMiss
from scipy.optimize import differential_evolution
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel, mutual_info_classif, RFECV
from sklearn.linear_model import LogisticRegression, LassoCV
from sklearn.metrics import ndcg_score, precision_score, recall_score, f1_score, matthews_corrcoef, roc_auc_score, \
    confusion_matrix, accuracy_score, classification_report, cohen_kappa_score
from sklearn.model_selection import KFold, train_test_split, LeaveOneOut
from sklearn.naive_bayes import BernoulliNB
from sklearn.neural_network import MLPClassifier
from sklearn.svm import LinearSVC, SVR
from sklearn.tree import DecisionTreeClassifier
from utils.cliffsDelta import cliffsDelta
from pytime import pytime
from sqlalchemy import create_engine
from tables import *
from tables.infra import Base
from sqlalchemy.orm import sessionmaker
import pandas
import numpy as np
import configparser
import os
import time, threading

class DevDefect:
    def __init__(self, id, name, project):
        self.id = id
        self.name = name

        self.project = project
        self.sentiment = []
        self.modality = []
        self.mood = []
        self.politeness_confidence_level = []
        self.politeness = []
        self.anger = []
        self.joy = []
        self.love = []
        self.sadness = []
        self.sentence = []
        self.arousal = []
        self.dominance = []
        self.valence = []
        self.comments = []
        self.comments_created_at = []

        self.smelly_ranges = []
        self.quit_ranges = []
        self.org_silo_ranges = []
        self.missing_links_ranges = []
        self.radiosilence_ranges = []
        self.black_cloud_ranges = []
        self.prima_donna_ranges = []

        self.ml_devs_ranges = []
        self.code_devs_ranges = []
        self.ml_code_devs_ranges = []
        self.sponsored_devs_ranges = []
        self.core_devs_ranges = []

    def append_sen(self,sen):
        '''

            res = {
            'ir_id': ir_id,
            'sentiment': sentiment,
            'modality': modality,
            'mood': mood,
            'politeness_confidence_level': politeness_confidence_level,
            'politeness': politeness,
            'anger': anger_count,
            'joy': joy_count,
            'love': love_count,
            'sadness': sadness_count,
            'sentence': sentence_count,
            'arousal': arousal_mean_sum,
            'dominance': dominance_mean_sum,
            'valence': valence_mean_sum,
            'author_id':author_id,
            'comment': comment,
            'created_at': created_at

        }
        '''
        if sen is None:
            return
        try:
            self.sentiment.append(sen['sentiment'])
        except:
            self.sentiment = [sen['sentiment']]
        self.modality.append(sen['modality'])
        self.mood.append(sen['mood'])
        self.politeness_confidence_level.append(sen['politeness_confidence_level'])
        self.politeness.append(sen['politeness'])
        self.anger.append(sen['anger'])
        self.joy.append(sen['joy'])
        self.love.append(sen['love'])
        self.sadness.append(sen['sadness'])
        self.sentence.append(sen['sentence'])
        self.arousal.append(sen['arousal'])
        self.dominance.append(sen['dominance'])
        self.valence.append(sen['valence'])
        # self.id =  self.author_id
        self.comments.append(sen['comment'])
        self.comments_created_at.append(sen['created_at'])

    def determine_smelly_ranges(self):
        self.smelly_ranges.extend(self.org_silo_ranges)
        self.smelly_ranges.extend(self.missing_links_ranges)
        self.smelly_ranges.extend(self.radiosilence_ranges)
        self.smelly_ranges.extend(self.black_cloud_ranges)
        self.smelly_ranges.extend(self.prima_donna_ranges)
        self.smelly_ranges = list(set(self.smelly_ranges))
        return self

def get_config(section, key):
    config = configparser.ConfigParser()
    path = os.path.split(os.path.realpath(__file__))[0] + '/project.conf'
    config.read(path)
    return config.get(section, key)


def parse_time(tgt):
    try:
        if ':' in tgt and '.' in tgt:
            return pytime.parse(tgt.split('.')[0])
        else:
            tgt = tgt.split(' -')[0]
            return pytime.parse(tgt)
    except Exception as e:
        print('date parse error '+tgt)
        return None

db_uri = get_config('database', 'url')
source_path = get_config('path', 'source')
tmp = get_config('path', 'tmp')
patch = get_config('path', 'patch')
tmp_base = source_path + tmp
patch_base = source_path + patch
codeface_report_base = get_config('path', 'codeface_report_base')
base = get_config('path', 'base')

codeface_result_base = get_config('path', 'codeface_dataset_results_base')

engine = create_engine(db_uri, echo=False)
Base.metadata.create_all(engine)
session = sessionmaker(bind=engine)()

def output_cliffsDelta(general_table_smelly,general_table_non_smelly,attr):
    print("\n============")
    print("cliff's d "+attr)
    print("============\n")
    attr_smelly = general_table_smelly[attr].reset_index(drop=True).dropna().replace("POLITE", 1).replace("IMPOLITE", 0)
    attr_nonsmelly = general_table_non_smelly[attr].reset_index(drop=True).dropna().replace("POLITE", 1).replace("IMPOLITE", 0)
    try:
        print(cliffsDelta(attr_smelly, attr_nonsmelly))
    except:
        print('error')

def output_mean(general_table_smelly,general_table_non_smelly,attr):
    print("\n============")
    print("mean "+attr)
    print("============\n")

    attr_smelly = general_table_smelly[attr].reset_index(drop=True).replace(0, np.NaN).dropna().replace("POLITE",1).replace("IMPOLITE",0)
    attr_smelly_sentences = general_table_smelly['sentence'].reset_index(drop=True).replace(0, np.NaN).dropna().sum()
    attr_nonsmelly = general_table_non_smelly[attr].reset_index(drop=True).replace(0, np.NaN).dropna().replace("POLITE",1).replace("IMPOLITE",0)
    attr_nonsmelly_sentences = general_table_non_smelly['sentence'].replace(0, np.NaN).reset_index(drop=True).dropna().sum()

    print("smelly mean")
    print(attr_smelly.mean())
    print("nonsmelly mean")
    print(attr_nonsmelly.mean())
    print("smelly mean div sentences")
    print(attr_smelly.sum() / attr_smelly_sentences)
    print("nonsmelly mean div sentences")
    print(attr_nonsmelly.sum() / attr_nonsmelly_sentences)
def extract_dev_sn_metrics(line):
    # Developer SN metrics
    range = line['range']
    devs = line['devs']
    ml_only_devs = line['ml.only.devs']
    code_only_devs = line['code.only.devs']
    ml_code_devs = line['ml.code.devs']
    perc_ml_only_devs = line['perc.ml.only.devs']
    perc_code_only_devs = line['perc.code.only.devs']
    perc_ml_code_devs = line['perc.ml.code.devs']
    sponsored_devs = line['sponsored.devs']
    ratio_sponsored = line['ratio.sponsored']
    return range, devs, ml_only_devs, code_only_devs, ml_code_devs, \
           perc_code_only_devs, perc_ml_only_devs, perc_ml_code_devs, \
           sponsored_devs, ratio_sponsored




def split_by_str(src, token):
    return src.split(token) if src is not None and not (src != src) else []

def extract_comment(comment):
    ir_id = comment.issue_report_id

    sentiment = comment.sentiment

    modality = comment.modality
    mood = comment.mood

    politeness_confidence_level = comment.politeness_confidence_level
    politeness = comment.politeness

    anger_count = comment.anger_count
    joy_count = comment.joy_count
    love_count = comment.love_count
    sadness_count = comment.sadness_count
    sentence_count = comment.sentence_count
    arousal_mean_sum = comment.arousal_mean_sum
    dominance_mean_sum = comment.dominance_mean_sum
    valence_mean_sum = comment.valence_mean_sum
    author_id = comment.author_id
    comment_str = comment.comment
    created_at = comment.creationdate
    res = {
            'ir_id': ir_id,
            'sentiment': sentiment,
            'modality': modality,
            'mood': mood,
            'politeness_confidence_level': politeness_confidence_level,
            'politeness': politeness,
            'anger': anger_count,
            'joy': joy_count,
            'love': love_count,
            'sadness': sadness_count,
            'sentence': sentence_count,
            'arousal': arousal_mean_sum,
            'dominance': dominance_mean_sum,
            'valence': valence_mean_sum,
            'author_id':author_id,
            'comment': comment_str,
            'created_at': created_at

        }
    if sentiment is not None or modality is not None or mood is not None or politeness_confidence_level is not None or politeness is not None \
        or anger_count is not None or joy_count is not None or sadness_count is not None or arousal_mean_sum is not None or dominance_mean_sum is not None \
        or valence_mean_sum is not None:
        return res
    else:
        # print(comment)
        print(res)
        return None
def extract_devs(line):
    # smells
    smelly_devs_names_org_silo  = line['smelly.devs.names.org.silo']
    smelly_devs_names_missing_links = line['smelly.devs.names.missing.links']
    smelly_devs_names_radiosilence = line['smelly.devs.names.radiosilence']
    smelly_devs_names_black_cloud = line['smelly.devs.names.black.cloud']
    smelly_devs_names_prima_donnas = line['smelly.devs.names.prima.donnas']

    smelly_devs_org_silo = line['smelly.devs.org.silo']
    smelly_devs_missing_links = line['smelly.devs.missing.links']
    smelly_devs_radiosilence = line['smelly.devs.radiosilence']
    smelly_devs_black_cloud = line['smelly.devs.black.cloud']
    smelly_devs_prima_donnas = line['smelly.devs.prima.donnas']

    smelly_devs_names_org_silo = split_by_str(smelly_devs_names_org_silo, ';')
    smelly_devs_names_missing_links = split_by_str(smelly_devs_names_missing_links, ';')
    smelly_devs_names_radiosilence = split_by_str(smelly_devs_names_radiosilence, ';')
    smelly_devs_names_black_cloud = split_by_str(smelly_devs_names_black_cloud, ';')
    smelly_devs_names_prima_donnas = split_by_str(smelly_devs_names_prima_donnas, ';')

    smelly_devs_org_silo = split_by_str(smelly_devs_org_silo, ';')
    smelly_devs_missing_links = split_by_str(smelly_devs_missing_links, ';')
    smelly_devs_radiosilence = split_by_str(smelly_devs_radiosilence, ';')
    smelly_devs_black_cloud = split_by_str(smelly_devs_black_cloud, ';')
    smelly_devs_prima_donnas = split_by_str(smelly_devs_prima_donnas, ';')
    return {
        'org_silo':smelly_devs_names_org_silo,
        'missing_links':smelly_devs_names_missing_links,
        'radiosilence':smelly_devs_names_radiosilence,
        'black_cloud':smelly_devs_names_black_cloud,
        'prima_donnas':smelly_devs_names_prima_donnas
    }

prjs = [
    # {
    #     "project": 'CloudStack',
    #     "project_path_name": 'cloudStack'
    # },
    {
        "project": 'Hadoop Common',
        "project_path_name": 'hadoop-common'
    },
    {
        "project": 'Hadoop HDFS',
        "project_path_name": 'hadoop-hdfs'
    },
    {
        "project": 'Hadoop Map/Reduce',
        "project_path_name": 'hadoop-mapreduce'
    },
    {
        "project": 'OFBiz',
        "project_path_name": 'ofbiz'
    },
    {
       "project": 'Camel',
       "project_path_name": 'camel'
    },
    # {
    #     "project": 'Pig',
    #     "project_path_name": 'pig'
    # },
    # {
    #     "project": 'Geronimo',
    #     "project_path_name": 'geronimo'
    # },
    {
        "project": 'ZooKeeper',
        "project_path_name": 'zookeeper'
    },
    {
        "project": 'HBase',
        "project_path_name": 'hbase'
    },
    {
        "project": 'Hive',
        "project_path_name": 'hive'
    },
    {
        "project": 'Hibernate ORM',
        "project_path_name": 'hibernate-orm'
    },
    {
        "project": 'Cassandra',
        "project_path_name": 'cassandra'
    },
    {
        "project": 'Harmony',
        "project_path_name": 'harmony'
    },
    {
        "project": 'Wicket',
        "project_path_name": 'wicket'
    },
]

def calculate_range(a,b):
    if a is None or b is None: return None
    return abs((a-b).days)

def map_priority(p):
    if p == 'Blocker': return 1
    if p == 'Critical': return 2
    if p == 'Major': return 3
    if p == 'Minor': return 4
    if p == 'Optional' or p=='Trivial': return 5

def calculate_mean(sen):
    newsen = {}
    newnewsen = {}
    for i in sen:
        for k, v in i.items():
            if newsen.get(k) is None:
                newsen[k] = []
            newsen[k].append(v)
    for k,v in newsen.items():
        if k in ['politeness_confidence_level','ir_id']: continue
        elif k == 'politeness':
            newnewsen['POLITE'] = len(list(filter(lambda a:  a is not None and a == a and a=='POLITE',v)))
            newnewsen['IMPOLITE'] = len(list(filter(lambda a:  a is not None and a == a and a=='IMPOLITE',v)))
        elif k == 'mood':
            newnewsen['IMPERATIVE'] = len(list(filter(lambda a:  a is not None and a == a and a == 1, v)))
            newnewsen['INDICATIVE'] = len(list(filter(lambda a:  a is not None and a == a and a == 0, v)))
            newnewsen['SUBJUNCTIVE'] = len(list(filter(lambda a:  a is not None and a == a and a == 3, v)))
            newnewsen['CONDITIONAL'] = len(list(filter(lambda a:  a is not None and a == a and a == 2, v)))
        elif k=='comment':
            newnewsen['comments'] = '@!NEXT!@'.join(v)
        elif k == 'author_id':
            newnewsen['authors'] = ';'.join(map(lambda a:str(a),v))
        elif k == 'sentiment':
            pos_sen = np.nansum(list(filter(lambda a: a is not None and a == a and a > 0, v)))
            neg_sen = np.nansum(list(filter(lambda a: a is not None and a == a and a < 0, v)))
            newnewsen['pos'] = pos_sen
            newnewsen['neg'] = neg_sen

        elif k == 'created_at':
            newnewsen['COMMENTS_DURATION'] = calculate_range(min(v),max(v))

        else:
            if len(v) > 0:
                newnewsen[k] = np.nansum(list(filter(lambda vv: vv==vv and vv is not None,v)))
            else:
                newnewsen[k] = 0
    # for k,v in sen.items():
    #     if isinstance(v, list) or isinstance(v, set):
    #         if len(v) > 0:
    #             newsen[k] = np.mean(v)
    #         else:
    #             newsen[k] = 0
    #     else:
    #         newsen[k] = v
    return newnewsen
def extract_versions(vs):
    if vs is None or len(vs) == 0: return ''
    return ';'.join(list(map(lambda b:b.name,list(filter(lambda a: a==a and a is not None,vs)))))

def extract_prj():
    rows = []
    for prj in prjs:
        for IR in session.query(JiraIssueReport).filter_by(project_name= prj['project']).all():
            row = {
                'VOTES': IR.votes,
                'WATCHERS': IR.watchers,
                'CREATE_RESOLVE_RANGE': calculate_range(IR.created, IR.resolved),
                'RESOLVE_UPDATE_RANGE': calculate_range(IR.resolved, IR.updated),
                'PRIORITY': map_priority(IR.priority),
                'SUBTASK': len(IR.subtasks),
                'ATTACHMENTS': len(IR.attachments),
                'COMMENTS': len(IR.comments),
                'CHANGELOGS': len(IR.changelogs),
                'affected_versions': extract_versions(IR.affected_versions),
                'fixed_versions': extract_versions(IR.fixed_versions),
                'key': IR.key,
                'project_name': IR.project_name,
                'title': IR.title,
                'desc': IR.description,
                'fixed': 1 if IR.resolution == 'Fixed' else 0 ,
                'status': IR.status,
                'type': IR.type
            }
            sentiments = []
            for comment in IR.comments:

                id = comment.author_id
                # print('nonsmelly'+str(id)+' '+prj['project_path_name'])
                sen = extract_comment(comment)
                if sen is not None:
                    sentiments.append(sen)
            newsen = calculate_mean(sentiments)
            row.update(newsen)
            print(row)
            rows.append(row)
        table = pandas.DataFrame(rows)
        table.to_csv('E:\\reports\\defect\\data.csv',index=False)
            # print(prj['project_path_name'])
            # print(table_non_smelly)
            # table_non_smelly.to_csv(non_smelly_path)
            # table_smelly.to_csv(smelly_path)
    table = pandas.DataFrame(rows)
    table.to_csv('E:\\reports\\defect\\data.csv', index=False)


def draw(df):
    corr = df.corr()
    plt.rcParams['figure.figsize'] = (9.0, 9.75)
    plt.rcParams['savefig.dpi'] = 200
    plt.rcParams['figure.dpi'] = 200
    # corrplot(df[head_x5].corr(), size_scale=400, marker='s')
    # sns.heatmap(corr, annot=False, square=True)
    grid_kws = {"height_ratios": (.9, .05), "hspace": .3}
    # sns.set_style("ticks", {"xtick.major.size": 8, "ytick.major.size": 8})
    sns.set(font_scale=0.6)
    hm = sns.heatmap(corr,
                cmap='coolwarm',
                annot=False,
                fmt=".1f",
                annot_kws={'size': 6},
                cbar=True,
                square=True,
                cbar_kws={"orientation": "vertical","shrink": 0.6},
                # xticklabels=labels,
                vmin=-1, vmax=1,
                # yticklabels=labels
                     )
    # hm.set_xticklabels(hm.get_xmajorticklabels(), fontsize=8)
    # hm.set_yticklabels(hm.get_ymajorticklabels(), fontsize=8)

    plt.show()
    # with open('E:\\pic.jpg','wb') as f1:
    #     plt.savefig(f1)

def normalize(y, min, max):
    tmp_y = minmax_scale(y, feature_range=(min, max))
    res = [round(i) for i in tmp_y]
    return res

def sort_groups(x,y):
    values = -np.sort(-y.unique())
    groups = []
    tmp = pandas.DataFrame(x)
    tmp['crit'] = y.to_list()
    tmp = tmp.sort_values(ascending=False,by = ['crit'])
    for idx,i in enumerate(values):
        val_tmp = tmp[tmp['crit']==i]
        groups.append(val_tmp.shape[0])
    newcrit = []
    for idx, i in enumerate(values):
        newcrit.extend([len(values)-idx] * tmp[tmp['crit']==i].shape[0])

    res_y = newcrit
    res_x = tmp.drop(['crit'], axis=1)
    return res_x,res_y,groups

def label_gain(num):
    res = [0]
    for i in range(1,num+1):
        res.append(pow(2,i)-1)
    return res

def sort_groups_priority(x,y):
    values = range(int(min(y)),int(max(y)+1))
    groups = []
    tmp = pandas.DataFrame(x)
    tmp['crit'] = y.to_list()
    tmp = tmp.sort_values(ascending=False,by = ['crit'])
    for i in values:
        val_tmp = tmp[tmp['crit']==i]
        groups.append(val_tmp.shape[0])
    res_y = tmp['crit']
    res_x = tmp.drop(['crit'], axis=1)
    return res_x,res_y,groups

def get_date(str_date):
    dmy = str_date.split('.')
    return datetime(int(dmy[0]), int(dmy[1]), int(dmy[2]))



def extract_dev():
    userDict = {}
    # sentiments = list()
    for prj in prjs:
        users = session.query(JiraUser).all()
        for user in users:
            for comment in session.query(JiraIssueComment).filter_by(author_id=user.id).all():
                if comment.creationdate < get_date(prj['start']) or comment.creationdate > get_date(prj['end']):
                    continue
                ir_id = comment.issue_report_id
                try:
                    IR = session.query(JiraIssueReport).filter_by(id=ir_id).one()
                except Exception as e:
                    # print(e)
                    continue
                if IR.project_name.lower() != prj['project'].lower():
                    # print('skipping')
                    continue
                sen = extract_comment(comment)
                # print(sen)
                # if sen is not None:
                #     sentiments.append(sen)
                userObj = userDict.get(user.name+'__'+prj['project'])
                if userObj is None:
                    userObj = DevDefect(id, user.name, prj['project'])
                userObj.append_sen(sen)
                userDict[user.name+'__'+prj['project']] = userObj
    with open('H:\\reports\\defect2\\user.pk', 'wb') as fw1:
        pickle.dump(userDict, fw1)
    return userDict

def exclude_none(a):
    return [x for x in a if x is not None and x == x]



def process_prj(user):

    quitter = len(user.quit_ranges)
    radioSilence = len(user.radiosilence_ranges)
    missingLinks = len(user.missing_links_ranges)
    orgSilo = len(user.org_silo_ranges)
    smelly = radioSilence+missingLinks+orgSilo > 0
    sentiment = exclude_none(user.sentiment)
    positiveSentiment = list(filter(lambda i: i > 0, sentiment))
    negativeSentiment = list(filter(lambda i: i < 0, sentiment))
    anger = exclude_none(user.anger)
    love = exclude_none(user.love)
    joy = exclude_none(user.joy)
    sadness = exclude_none(user.sadness)
    arousal = exclude_none(user.arousal)
    valence = exclude_none(user.valence)
    dominance = exclude_none(user.dominance)
    modality = exclude_none(user.modality)
    mood = exclude_none(user.mood)
    politeness = exclude_none(user.politeness)
    return {
        'name': user.name,
        'sentiment': np.nanmean(sentiment) if len(sentiment) > 0 else 0,
        'anger': np.nanmean(anger) if len(anger) > 0 else 0,
        'love': np.nanmean(love) if len(love) > 0 else 0,
        'joy': np.nanmean(joy) if len(joy) > 0 else 0,
        'sadness': np.nanmean(sadness) if len(sadness) > 0 else 0,
        'arousal': np.nanmean(arousal) if len(arousal) > 0 else 0,
        'valence': np.nanmean(valence) if len(valence) > 0 else 0,
        'dominance': np.nanmean(dominance) if len(dominance) > 0 else 0,
        'modality': np.nanmean(modality) if len(modality) > 0 else 0,
        'mood_indicative': len(list(filter(lambda i: i == 0, mood))) / len(mood) if len(mood) > 0 else 0,
        'mood_imperative': len(list(filter(lambda i: i == 1, mood))) / len(mood) if len(mood) > 0 else 0,
        'mood_conditional': len(list(filter(lambda i: i == 2, mood))) / len(mood)  if len(mood) > 0 else 0,
        'mood_subjunctive': len(list(filter(lambda i: i == 3, mood))) / len(mood) if len(mood) > 0 else 0,

        'polite': len(list(filter(lambda i: i == i and i == 'POLITE', politeness))) / len(politeness) if len(
            politeness) > 0 else 0,
        'meanNegativeSentiment': np.nanmean(negativeSentiment) if len(negativeSentiment) > 0 else 0,
        'meanPositiveSentiment': np.nanmean(positiveSentiment) if len(positiveSentiment) > 0 else 0,
        'core': len(user.core_devs_ranges),
        'sentences': np.nanmean([0] if len(exclude_none(user.sentence)) < 1 else exclude_none(user.sentence)),
        'code_devs': len(user.code_devs_ranges),
        'ml_devs': len(user.ml_devs_ranges),
        'sponsored': len(user.sponsored_devs_ranges),

        'radioSilence': radioSilence,
        'missingLinks': missingLinks,
        'orgSilo': orgSilo,
        'smelly': smelly,
        'quitter': quitter
    }

table = pandas.read_csv('E:\\reports\\defect\\data.csv')

def get_user_exp(user,date):
    id = user.id
    if date is None:
        date = get_date('2022.2.2')
    exp_ass_bug = session.query(JiraIssueReport).filter(JiraIssueReport.assignee_id==id, JiraIssueReport.type.in_(['Bug','Defect']), JiraIssueReport.created<date).count()
    exp_ass_all = session.query(JiraIssueReport).filter(JiraIssueReport.assignee_id==id, JiraIssueReport.created<date).count()
    exp_ass_bug_prop = exp_ass_bug / exp_ass_all if exp_ass_all != 0 else 0
    exp_rep_bug = session.query(JiraIssueReport).filter(JiraIssueReport.reporter_id==id, JiraIssueReport.type.in_(['Bug','Defect']), JiraIssueReport.created<date).count()
    exp_rep_all = session.query(JiraIssueReport).filter(JiraIssueReport.reporter_id==id, JiraIssueReport.created<date).count()
    exp_rep_bug_prop = exp_rep_bug / exp_rep_all if exp_rep_all != 0 else 0
    exp_comment_all_iter = session.query(JiraIssueComment).filter(JiraIssueComment.author_id==id, JiraIssueComment.creationdate<date)
    exp_comment_bug = 0
    exp_comment_all = 0
    for i in exp_comment_all_iter:
        exp_comment_all += 1
        ir_id = i.issue_report_id
        IR =  session.query(JiraIssueReport).filter(JiraIssueReport.id==ir_id).one()
        if IR.type in ['Bug','Defect']:
            exp_comment_bug+=1
    exp_comment_prop = exp_comment_bug / exp_comment_all if exp_comment_all != 0 else 0
    return {'exp_ass_bug':exp_ass_bug,
            'exp_ass_all': exp_ass_all,
            'exp_ass_bug_prop': exp_ass_bug_prop,
            'exp_rep_bug':exp_rep_bug,
            'exp_rep_all':exp_rep_all,
           'exp_rep_bug_prop':exp_rep_bug_prop,
           'exp_comment_bug':exp_comment_bug,
           'exp_comment_all':exp_comment_all,
           'exp_comment_prop':exp_comment_prop
    }

def extend_single_prj(prj):
    print('starting '+prj['project'])
    table_new = pandas.DataFrame()
    dev_pk_path = codeface_report_base + prj['project_path_name'] + '_smelly.pk'
    with open(dev_pk_path, 'rb') as fw:
        userDict = pickle.load(fw)
    for i, row in table[table['project_name'] == prj['project']].iterrows():
        IR = session.query(JiraIssueReport).filter_by(key=row.key).one()
        reporter = session.query(JiraUser).filter_by(id=IR.reporter_id).one()
        reporter_exp = get_user_exp(reporter, IR.created)
        for k, v in reporter_exp.items():
            row['rep_' + k] = v
        if IR.assignee_id is not None:
            assignee = session.query(JiraUser).filter_by(id=IR.assignee_id).one()
            assignee_sen = userDict.get(assignee.name)
            assignee_exp = get_user_exp(assignee, IR.created)
            for k, v in assignee_exp.items():
                row['ass_' + k] = v
            if assignee_sen is not None:
                ass = process_prj(assignee_sen)
                for k, v in ass.items():
                    row['ass_' + k] = v
        reporter_sen = userDict.get(reporter.name)
        if reporter_sen is not None:
            rep = process_prj(reporter_sen)
            for k, v in rep.items():
                row['rep_' + k] = v

        table_new = table_new.append(row)
    table_new.to_csv('H:\\reports\\defect2\\data_new_mean_'+prj['project_path_name']+'.csv')

def integrate(appen,type,k):
    data = pandas.DataFrame()
    for prj in prjs:
        data_path = 'H:\\reports\\defect2\\data_new_' + appen+prj['project_path_name'] +'_'+type+ '_'+str(k)+'.csv'
        data=data.append(pandas.read_csv(data_path), ignore_index=True)
    try:
        del data['comments']
        del data['title']
    except:
        print('delete failed')
    data.to_csv('e:\\reports\\defect\\data_mini_6'+'_'+type+'_'+str(k)+'.csv', index=False)

def add_date(type,kk):
    data = pandas.read_csv('e:\\reports\\defect\\data_mini_6'+'_'+type+'_'+str(kk)+'.csv')
    new_data = pandas.DataFrame()
    rep_time_path = 'H:\\reports\\defect2\\rep_time.pk'
    with open(rep_time_path, 'rb') as f3:
        rep_time = pickle.load(f3)
    for i,d in data.iterrows():
        k = d['key'].split('-')[0]
        d['project'] = k
        time_entity = rep_time[d['key']]
        d['updated_at'] = time_entity['updated_at']
        new_data = new_data.append(d)
    new_data.to_csv('e:\\reports\\defect\\data_mini_7'+'_'+type+'_'+str(kk)+'.csv')

def extend_prj():
    # extend_single_prj(prjs[0])
    cores = multiprocessing.cpu_count()
    pool = multiprocessing.Pool(processes=cores)
    pool.map(extend_single_prj, prjs)

def process_documents(data):
    documents = list()
    docs = {}
    for i, line in data[['key', 'title', 'comments', 'desc']].iterrows():
        comments = '' if line['comments'] != line['comments'] else ''.join(line['comments'].split('@!NEXT!@'))
        desc = '' if line['desc'] != line['desc'] else line['desc']
        title = '' if line['title'] != line['title'] else line['title']
        txt = preprocess_string((remove_stopwords(title + desc + comments)))
        if txt is '':
            print(line['key'] + ' is empty')
        docs[line['key']] = txt
        documents.append(TaggedDocument(txt, [line['key']]))
    return docs, documents

def process_documents_export(data):
    documents = list()
    documents_for_training = ''
    docs = []
    docs_final = ''
    contents = []
    labels = []
    for i, line in data[['key', 'title', 'desc', 'pos', 'neg', 'PRIORITY']].iterrows():
        p = None
        try:
            p = int(line['PRIORITY'])
            # if p >= 4: p=3
            # elif p == 3 : p = 2
            # elif p <= 2 : p = 1
        except:
            continue
        # comments = '' if line['comments'] != line['comments'] else ''.join(line['comments'].split('@!NEXT!@'))
        desc = '' if line['desc'] != line['desc'] else line['desc']
        title = '' if line['title'] != line['title'] else line['title']
        summary_processed = ' '.join(preprocess_string((remove_stopwords(title))))
        try:
            description_processed = ' '.join(preprocess_string((remove_stopwords(desc))))
        except:
            description_processed=''
        sentiment = 'positive'
        if abs(line['pos']) <= 1 and abs(line['neg'])<=1:
            sentiment = 'neutral'
        elif abs(line['pos']) >= 1 and abs(line['neg']) <=1:
            sentiment = 'positive'
        elif abs(line['neg']) >= 1 and abs(line['pos']) <= 1:
            sentiment = 'negative'
        elif abs(line['neg'])-abs(line['pos'])>=1:
            sentiment = 'negative'
        elif abs(line['pos'])-abs(line['neg'])>=1:
            sentiment = 'positive'
        else:
            sentiment = 'neutral'

        if summary_processed == '' and description_processed == '':
            print(line['key'] + ' is empty')
            continue
        docs.append(line['key'].split('-')[1]+','+summary_processed+','+description_processed+','+str(int(p)))
        contents.append(summary_processed+' '+description_processed)
        documents.append((sentiment+' '+summary_processed+' '+description_processed).split(' '))
        documents_for_training+=(sentiment+' '+summary_processed+' '+description_processed)+'<SEP>'+str(int(p)-1)+'\n'
        labels.append(str(int(p)-1))

    corpus = list()
    doc_tags = list()
    for i,line in enumerate(contents):
        doc_tags.append(i)
        corpus.append(line.split(' '))
    dictionary = corpora.Dictionary(corpus)
    corpus = [dictionary.doc2bow(line) for line in corpus]
    ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics=30)
    for i,line in enumerate(contents):
        t,proba = sorted(ldamodel.get_document_topics(dictionary.doc2bow(line.split(' '))), key=lambda x:(-x[1],x[0]))[0]

        docs_arr = docs[i].split(',')
        docs_arr.append(docs_arr[-1])
        docs_arr[-2]=str(t)
        docs[i] = ','.join(docs_arr)
    docs_final = '\n'.join(docs)
    return docs_final, documents, documents_for_training, labels


def process_documents_export_notopic(data):
    documents = list()
    documents_for_training = ''
    docs = []
    docs_final = ''
    contents = []
    labels = []
    for i, line in data[['key', 'title', 'desc', 'pos', 'neg', 'PRIORITY']].iterrows():
        p = None
        try:
            p = int(line['PRIORITY'])
            # if p >= 4: p=3
            # elif p == 3 : p = 2
            # elif p <= 2 : p = 1
        except:
            continue
        # comments = '' if line['comments'] != line['comments'] else ''.join(line['comments'].split('@!NEXT!@'))
        desc = '' if line['desc'] != line['desc'] else line['desc']
        title = '' if line['title'] != line['title'] else line['title']
        summary_processed = ' '.join(preprocess_string((remove_stopwords(title))))
        try:
            description_processed = ' '.join(preprocess_string((remove_stopwords(desc))))
        except:
            description_processed = ''
        sentiment = 'positive'
        if abs(line['pos']) <= 1 and abs(line['neg'])<=1:
            sentiment = 'neutral'
        elif abs(line['pos']) >= 1 and abs(line['neg']) <=1:
            sentiment = 'positive'
        elif abs(line['neg']) >= 1 and abs(line['pos']) <= 1:
            sentiment = 'negative'
        elif abs(line['neg'])-abs(line['pos'])>=1:
            sentiment = 'negative'
        elif abs(line['pos'])-abs(line['neg'])>=1:
            sentiment = 'positive'
        else:
            sentiment = 'neutral'

        if summary_processed == '' and description_processed == '':
            print(line['key'] + ' is empty')
            continue
        docs.append(line['key'].split('-')[1]+','+summary_processed+','+description_processed+','+str(int(p)))
        contents.append(summary_processed+' '+description_processed)
        documents.append((sentiment+' '+summary_processed+' '+description_processed).split(' '))
        documents_for_training+=(sentiment+' '+summary_processed+' '+description_processed)+'<SEP>'+str(int(p)-1)+'\n'
        labels.append(str(int(p)-1))
    # corpus = list()
    # doc_tags = list()
    # for i,line in enumerate(contents):
    #     doc_tags.append(i)
    #     corpus.append(line.split(' '))
    # dictionary = corpora.Dictionary(corpus)

    return documents, documents_for_training, labels


def dump_k_sim(corpus_path, model_path, sim_result_path, data, type,k):
    lsi_corpus_path_arr = corpus_path.split('.pk')
    lsi_corpus_path = lsi_corpus_path_arr[0]+'_lsi.pk'
    lsi_corpus_dict_path = lsi_corpus_path_arr[0]+'_dict_lsi.pk'
    lsi_corpus_tfidf_path = lsi_corpus_path_arr[0]+'_tfidf_lsi.pk'
    lsi_corpus_tags_path = lsi_corpus_path_arr[0]+'_tags_lsi.pk'

    if os.access(corpus_path, os.F_OK):
        with open(corpus_path, 'rb') as f1:
            docs = pickle.load(f1)
        # if type is not 'd2v':
        #     with open(lsi_corpus_path, 'rb') as f2:
        #         documents = pickle.load(f2)
    else:
        docs, documents = process_documents(data)
        corpus = list()
        doc_tags = list()
        for doc_tag, doc_corpus in docs.items():
            doc_tags.append(doc_tag)
            corpus.append(doc_corpus)
        dictionary = corpora.Dictionary(corpus)
        corpus = [dictionary.doc2bow(line) for line in corpus]

        with open(corpus_path, 'wb') as f1:
            pickle.dump(docs, f1)
        if type is not 'd2v':
            with open(lsi_corpus_path,'wb') as f2:
                pickle.dump(corpus, f2)
            with open(lsi_corpus_dict_path,'wb') as f3:
                pickle.dump(dictionary, f3)
            with open(lsi_corpus_tags_path, 'wb') as f4:
                pickle.dump(doc_tags, f4)
        if type is 'd2v':
            model = Doc2Vec(documents, vector_size=5, window=2, min_count=1, workers=4)
        else:
            if not os.access(lsi_corpus_tfidf_path, os.F_OK):
                tfidf = TfidfModel(dictionary=dictionary)
                tfidf.save(lsi_corpus_tfidf_path)
            else:
                tfidf = TfidfModel.load(lsi_corpus_tfidf_path)
            corpus_tfidf = tfidf[corpus]

            model = LsiModel(corpus_tfidf, num_topics=200, id2word=dictionary)

        model.save(model_path)
    if type is 'd2v':
        model = Doc2Vec.load(model_path)
    else:
        model = LsiModel.load(model_path)
    simres = gen_sim_res(docs, data, model, type,lsi_corpus_path,lsi_corpus_dict_path,lsi_corpus_tags_path,k)

    with open(sim_result_path,'wb') as f2:
        pickle.dump(simres, f2)


def dump_dataset(corpus_path, model_path, data, full_path, train_path, test_path, dev_path):

    docs, documents, documents_for_training, labels = process_documents_export(data)

    # model = Word2Vec(documents)
    # model.save(model_path)
    with open(corpus_path, 'w', encoding='utf-8') as f1:
        f1.write(docs)
        f1.close()
    #
    # arr = documents_for_training.split('\n')[:-1]
    #
    # try:
    #     arr_train, arr_test, y_train, y_test = train_test_split(arr, labels, stratify=labels, test_size=0.2, random_state=0)
    #     arr_train, arr_dev, y_train, y_test = train_test_split(arr, labels, stratify=labels, test_size=0.2, random_state=0)
    # except:
    #     return
    #
    # with open(full_path, 'w', encoding='utf-8') as f1:
    #     f1.write(documents_for_training)
    #     f1.close()
    #
    # with open(test_path, 'w', encoding='utf-8') as f1:
    #     f1.write('\n'.join(arr_test))
    #     f1.close()
    #
    #
    # with open(train_path, 'w', encoding='utf-8') as f1:
    #     f1.write('\n'.join(arr_train))
    #     f1.close()
    #
    # with open(dev_path, 'w', encoding='utf-8') as f1:
    #     f1.write('\n'.join(arr_dev))
    #     f1.close()

    # if type is 'd2v':
    #     model = Word2Vec.load(model_path)


def dump_dataset_cross(corpus_path, model_path, data_test, data_train, full_path, train_path, test_path, dev_path):
    # with open(full_path, 'r', encoding='utf-8') as f1:
    #     text = f1.readlines()
    # if not os.access(model_path, os.F_OK):
        # documents_abandon, documents_all = process_documents_export_notopic(data_test.append(data_train,ignore_index=True))
    # real_text = list()
    # for i in text:
    #     real_text.append(i.split('<SEP>')[0].split(' '))
    # model = Word2Vec(real_text)
    # model.save(model_path)
    # with open(corpus_path, 'w', encoding='utf-8') as f1:
    #     f1.write(docs)
    #     f1.close()


    docs_final, documents, documents_for_training,labels = process_documents_export(data_train)
    # documents_test, documents_for_testing,labels_test = process_documents_export_notopic(data_test)

    # arr = documents_for_training.split('\n')[:-1]
    # arr_train, arr_test, y_train, y_test = train_test_split(arr, labels, stratify=labels, test_size=0.2, random_state=0)
    # try:
    #
    #     arr_train, arr_dev, y_train, y_test = train_test_split(arr, labels, stratify=labels, test_size=0.2, random_state=0)
    # except:
    #     return

    with open(full_path, 'w', encoding='utf-8') as f1:
        f1.write(docs_final)
        f1.close()

    # with open(test_path, 'w', encoding='utf-8') as f1:
    #     f1.write(documents_for_testing)
    #     f1.close()
    #
    #
    # with open(train_path, 'w', encoding='utf-8') as f1:
    #     f1.write('\n'.join(arr_train))
    #     f1.close()
    #
    # with open(dev_path, 'w', encoding='utf-8') as f1:
    #     f1.write('\n'.join(arr_dev))
    #     f1.close()
    #
    # if type is 'd2v':
    #     model = Word2Vec.load(model_path)



def gen_sim_res(docs,data,model,type,lsi_corpus_path,lsi_corpus_dict_path,lsi_corpus_tags_path,k):
    simres = {}
    if type is not 'd2v':
        with open(lsi_corpus_path, 'rb') as f2:
            corpus = pickle.load(f2)
        with open(lsi_corpus_dict_path, 'rb') as f3:
            dictionary = pickle.load(f3)
        with open(lsi_corpus_tags_path, 'rb') as f4:
            tags = pickle.load(f4)
    for kk, v in docs.items():
        line = list(data[data.key == kk].iterrows())[0][1]
        # comments = '' if line['comments']!= line['comments'] else  ''.join(line['comments'].split('@!NEXT!@'))
        desc = '' if line['desc'] != line['desc'] else line['desc']
        title = '' if line['title'] != line['title'] else line['title']
        v = preprocess_string((remove_stopwords(title + desc)))

        if type is 'd2v':
            inferred = model.infer_vector(v)
            sims = model.docvecs.most_similar([inferred], topn=int(len(docs)))
            simres[kk] = sims
        else:
            vec_bow = dictionary.doc2bow(v)
            vec_lsi = model[vec_bow]  # convert the query to LSI space
            index = similarities.MatrixSimilarity(model[corpus])
            sims = index[vec_lsi]
            sims = sorted(enumerate(sims), key=lambda item: -item[1])
            res = list()
            i = 0
            for sim in sims:
                i+=1
                # if i > 30: continue
                if i > k: continue
                (id_doc, val) = sim
                res.append((tags[id_doc],val))
            simres[kk] = res
    return simres

def top_k_similar(type,k):
    input_list = []
    for prj in prjs:
        data_path = 'H:\\reports\\defect2\\data_new_mean_' + prj['project_path_name'] +'.csv'
        model_path = 'H:\\reports\\defect2\\data_new_mean_' + prj['project_path_name'] + '_'+type+'_'+str(k)+'.model'
        corpus_path = 'H:\\reports\\defect2\\data_new_mean_' + prj['project_path_name'] +'_'+type+'_'+str(k)+'.pk'
        sim_result_path = 'H:\\reports\\defect2\\data_new_mean_sim_removecomment' + prj['project_path_name'] + '_'+type+'.pk'
        data = pandas.read_csv(data_path)
        input_list.append([corpus_path, model_path, sim_result_path, data, type, k])

    cores = multiprocessing.cpu_count()
    pool = multiprocessing.Pool(processes=cores)
    pool.starmap(dump_k_sim, input_list)

def group_by_time(table):
    pairs = []
    months = []
    years = []
    my = []
    pairs_res = []
    for i in pandas.to_datetime(table['updated_at']):
        months.append(i.month)
        years.append(i.year)
        my.append(i.month + i.year * 100)
    table['month'] = months
    table['year'] = years
    table['my'] = my
    grouped = table \
        .groupby(by=['month', 'year'])
    months = list(range(1, 13))
    years = np.unique(years)
    i = 0
    tps = []
    for y in years:
        for m in list(range(1, 13)):
            group_names = list(grouped.groups.keys())
            if (m, y) in group_names:
                tps.append((m, y))
    r = int(grouped.ngroups * 0.2)
    for i in range(0, int(len(tps) - r * 3)):
        data1 = grouped.get_group(tps[i])
        for j in range(1, r + 1):
            data1 = data1.append(grouped.get_group((tps[i + j])))
        data2 = grouped.get_group(tps[i + r])
        for j in range(r * 2 + 1, r * 3):
            data2 = data2.append(grouped.get_group((tps[i + j])))
        pairs.append((data1, data2))

    for pair in pairs:
        try:
            data1, data2 = pair
        except:
            continue
        x_train = data1.replace(np.nan, 0)
        x_test = data2.replace(np.nan, 0)
        pairs_res.append((x_train,x_test))
    return pairs_res


def export_dataset():
    input_list = []
    for prj in prjs:
        data_path = 'E:\\reports\\defect\\data_new_mean_' + prj['project_path_name'] +'.csv'
        model_path = 'H:\\reports\\defect2\\data_trel_' + prj['project_path_name'] + '_w2v.model'
        corpus_path = 'H:\\reports\\defect2\\data_trel_' + prj['project_path_name'] +'.txt'
        train_path = 'H:\\reports\\defect2\\data_trel_' + prj['project_path_name'] +'_train.txt'
        test_path = 'H:\\reports\\defect2\\data_trel_' + prj['project_path_name'] +'_test.txt'
        dev_path = 'H:\\reports\\defect2\\data_trel_' + prj['project_path_name'] +'_dev.txt'
        full_path = 'H:\\reports\\defect2\\data_trel_' + prj['project_path_name'] +'_full.txt'

        data = pandas.read_csv(data_path)
        if not os.access(train_path,os.F_OK):
            input_list.append([corpus_path, model_path, data, full_path, train_path, test_path, dev_path])
            print('train')

    pool = multiprocessing.Pool(processes=5)
    pool.starmap(dump_dataset, input_list)


def top_k_similar_cross(type,k):
    data = pandas.DataFrame()
    for prj in prjs:
        data_path = 'E:\\reports\\defect\\data_new_mean_' +prj['project_path_name']+ '.csv'
        data = data.append(pandas.read_csv(data_path),ignore_index=True)
        data = data[data['type']=='Bug']
    model_path = 'H:\\reports\\defect2\\data_new_mean_' +type+'_'+str(k)+ '.model'
    corpus_path = 'H:\\reports\\defect2\\data_new_mean_'+type+'_'+str(k)+ '.pk'
    sim_result_path = 'H:\\reports\\defect2\\data_new_mean_sim_removecomment' +type+'.pk'
    dump_k_sim(corpus_path, model_path, sim_result_path, data, type, k)

def normalize_list_numpy(list_numpy):
    normalized_list = minmax_scale(list_numpy)
    return normalized_list

def do_extend_prj_top_k_metric(prj, type, k):
    print(prj['project'])
    # factors_ticket = 'VOTES;WATCHERS;CREATE_RESOLVE_RANGE;RESOLVE_UPDATE_RANGE;SUBTASK;ATTACHMENTS;COMMENTS;CHANGELOGS;sentence;COMMENTS_DURATION'
    # factors_sentiment = 'pos;neg;modality;IMPERATIVE;INDICATIVE;SUBJUNCTIVE;CONDITIONAL;POLITE;IMPOLITE;anger;joy;love;sadness;arousal;dominance;valence'
    # factors = []
    # factors.extend(factors_ticket.split(';'))
    # factors.extend(factors_sentiment.split(';'))
    factors = 'ATTACHMENTS,CHANGELOGS,COMMENTS,COMMENTS_DURATION,CONDITIONAL,CREATE_RESOLVE_RANGE,IMPERATIVE,IMPOLITE,INDICATIVE,POLITE,PRIORITY,RESOLVE_UPDATE_RANGE,SUBJUNCTIVE,SUBTASK,VOTES,WATCHERS,anger,arousal,ass_anger,ass_arousal,ass_code_devs,ass_core,ass_dominance,ass_joy,ass_love,ass_meanNegativeSentiment,ass_meanPositiveSentiment,ass_missingLinks,ass_ml_devs,ass_modality,ass_mood_conditional,ass_mood_imperative,ass_mood_indicative,ass_mood_subjunctive,ass_orgSilo,ass_polite,ass_quitter,ass_radioSilence,ass_sadness,ass_sentences,ass_sentiment,ass_smelly,ass_sponsored,ass_valence,dominance,fixed,joy,love,modality,neg,pos,rep_anger,rep_arousal,rep_code_devs,rep_core,rep_dominance,rep_joy,rep_love,rep_meanNegativeSentiment,rep_meanPositiveSentiment,rep_missingLinks,rep_ml_devs,rep_modality,rep_mood_conditional,rep_mood_imperative,rep_mood_indicative,rep_mood_subjunctive,rep_orgSilo,rep_polite,rep_quitter,rep_radioSilence,rep_sadness,rep_sentences,rep_sentiment,rep_smelly,rep_sponsored,rep_valence,sadness,sentence,valence,ass_exp_ass_all,ass_exp_ass_bug,ass_exp_ass_bug_prop,ass_exp_comment_all,ass_exp_comment_bug,ass_exp_comment_prop,ass_exp_rep_all,ass_exp_rep_bug,ass_exp_rep_bug_prop,rep_exp_ass_all,rep_exp_ass_bug,rep_exp_ass_bug_prop,rep_exp_comment_all,rep_exp_comment_bug,rep_exp_comment_prop,rep_exp_rep_all,rep_exp_rep_bug,rep_exp_rep_bug_prop'.split(',')
    pandas.options.mode.chained_assignment = None  # default='warn'

    new_res = pandas.DataFrame()
    sim_result_path = 'H:\\reports\\defect2\\data_new_mean_sim_removecomment' + prj['project_path_name'] + '_'+type+'.pk'
    data_path = 'H:\\reports\\defect2\\data_new_mean_' + prj['project_path_name'] +'.csv'
    new_res_path = 'H:\\reports\\defect2\\data_new_mean_sim_' + prj['project_path_name'] + '_'+type+'_'+str(k)+'.csv'
    if os.access(new_res_path, os.F_OK):
        return
    data = pandas.read_csv(data_path)
    rep_time_path = 'H:\\reports\\defect2\\rep_time.pk'
    with open(rep_time_path, 'rb') as f3:
        rep_time = pickle.load(f3)
    with open(sim_result_path, 'rb') as f2:
        sim = pickle.load(f2)
    for key, sims in sim.items():
        print(key)
        try:
            if rep_time.get(key) is None: continue
            created_at = rep_time[key]['created_at']
            sim_minmaxed = []
            sim_names = []
            c = 0
            for s in sims:
                if c>k:
                    break
                (name, similarity) = s
                s_created_at = rep_time[name]['created_at']

                if name == key or s_created_at>=created_at:
                    continue
                sim_names.append(name)
                sim_minmaxed.append(similarity)
                c+=1
            if len(sim_minmaxed) > 1:
                sim_minmaxed = normalize_list_numpy(sim_minmaxed)
            elif  len(sim_minmaxed) > 0:
                sim_minmaxed = [1]
            features = pandas.DataFrame()
            priority = []
            for i,s in enumerate(sim_names):
                weight = sim_minmaxed[i]
                row = data[data['key'] == s]
                priority.append(row['PRIORITY'])
                features = features.append(row[factors] * weight)
            prop_blocker = 0
            prop_critical = 0
            prop_trivial = 0
            prop_minor = 0

            i = 0

            for s in priority:
                val = s.values[0]
                if val == 1:
                    prop_blocker += sim_minmaxed[i]
                elif val == 2:
                    prop_critical += sim_minmaxed[i]
                elif val == 4:
                    prop_minor += sim_minmaxed[i]
                elif val == 5:
                    prop_trivial += sim_minmaxed[i]
                i+=1
            sum_sim_minaxed = np.sum(sim_minmaxed) if len(sim_minmaxed)>1 else 1
            if sum_sim_minaxed == 0:
                sum_sim_minaxed = 1
            prop_blocker /= sum_sim_minaxed
            prop_critical /= sum_sim_minaxed
            prop_minor /= sum_sim_minaxed
            prop_trivial /= sum_sim_minaxed

            features = features.mean()


            considered_row = data[data['key'] == key]
            for f in factors:
                try:
                    considered_row['sim_' + f] = features[f]
                except:
                    considered_row['sim_' + f] = 0

            considered_row['sim_PROP_BLOCKER'] = prop_blocker
            considered_row['sim_PROP_SEVERE'] = prop_critical
            considered_row['sim_PROP_MINOR'] = prop_minor
            considered_row['sim_PROP_TRIVIAL'] = prop_trivial
            considered_row['is_bug'] = 1 if considered_row['type'].values[0] in ['Bug','Defect'] else 0
            del considered_row['comments']
            del considered_row['title']
            del considered_row['desc']
            del considered_row['type']

            new_res = new_res.append(considered_row, ignore_index=True)
        except Exception as e:
            print(e)
    new_res.to_csv(new_res_path, index=False)

def do_extend_prj_top_k_metric_cross(type,k):
    # factors_ticket = 'VOTES;WATCHERS;CREATE_RESOLVE_RANGE;RESOLVE_UPDATE_RANGE;SUBTASK;ATTACHMENTS;COMMENTS;CHANGELOGS;sentence;COMMENTS_DURATION'
    # factors_sentiment = 'pos;neg;modality;IMPERATIVE;INDICATIVE;SUBJUNCTIVE;CONDITIONAL;POLITE;IMPOLITE;anger;joy;love;sadness;arousal;dominance;valence'
    # factors = []
    # factors.extend(factors_ticket.split(';'))
    # factors.extend(factors_sentiment.split(';'))
    factors = 'ATTACHMENTS,CHANGELOGS,COMMENTS,COMMENTS_DURATION,CONDITIONAL,CREATE_RESOLVE_RANGE,IMPERATIVE,IMPOLITE,INDICATIVE,POLITE,PRIORITY,RESOLVE_UPDATE_RANGE,SUBJUNCTIVE,SUBTASK,VOTES,WATCHERS,anger,arousal,ass_anger,ass_arousal,ass_code_devs,ass_core,ass_dominance,ass_joy,ass_love,ass_meanNegativeSentiment,ass_meanPositiveSentiment,ass_missingLinks,ass_ml_devs,ass_modality,ass_mood_conditional,ass_mood_imperative,ass_mood_indicative,ass_mood_subjunctive,ass_orgSilo,ass_polite,ass_quitter,ass_radioSilence,ass_sadness,ass_sentences,ass_sentiment,ass_smelly,ass_sponsored,ass_valence,dominance,fixed,joy,love,modality,neg,pos,rep_anger,rep_arousal,rep_code_devs,rep_core,rep_dominance,rep_joy,rep_love,rep_meanNegativeSentiment,rep_meanPositiveSentiment,rep_missingLinks,rep_ml_devs,rep_modality,rep_mood_conditional,rep_mood_imperative,rep_mood_indicative,rep_mood_subjunctive,rep_orgSilo,rep_polite,rep_quitter,rep_radioSilence,rep_sadness,rep_sentences,rep_sentiment,rep_smelly,rep_sponsored,rep_valence,sadness,sentence,valence,ass_exp_ass_all,ass_exp_ass_bug,ass_exp_ass_bug_prop,ass_exp_comment_all,ass_exp_comment_bug,ass_exp_comment_prop,ass_exp_rep_all,ass_exp_rep_bug,ass_exp_rep_bug_prop,rep_exp_ass_all,rep_exp_ass_bug,rep_exp_ass_bug_prop,rep_exp_comment_all,rep_exp_comment_bug,rep_exp_comment_prop,rep_exp_rep_all,rep_exp_rep_bug,rep_exp_rep_bug_prop'.split(',')
    pandas.options.mode.chained_assignment = None  # default='warn'

    new_res = pandas.DataFrame()
    sim_result_path = 'H:\\reports\\defect2\\data_new_mean_sim_removecomment' +'_'+type+'.pk'
    new_res_path = 'H:\\reports\\defect2\\data_new_mean_sim_' +type+'_'+str(k)+'.csv'
    if os.access(new_res_path, os.F_OK):
        return
    data = pandas.DataFrame()
    for prj in prjs:
        data_path = 'H:\\reports\\defect2\\data_new_mean_' +prj['project_path_name']+'.csv'
        data2append = pandas.read_csv(data_path)
        data = data.append(data2append,ignore_index=True)
    data = data[data['type']=='Bug']
    with open(sim_result_path, 'rb') as f2:
        sim = pickle.load(f2)
    for key, sims in sim.items():
        print(key)
        try:
            sim_minmaxed = []
            sim_names = []
            c = 0
            for s in sims:
                if c>k:
                    break
                (name, similarity) = s
                if name == key:
                    continue
                sim_names.append(name)
                sim_minmaxed.append(similarity)
                c+=1
            if len(sim_minmaxed) > 1:
                sim_minmaxed = normalize_list_numpy(sim_minmaxed)
            elif  len(sim_minmaxed) > 0:
                sim_minmaxed = [1]
            features = pandas.DataFrame()
            priority = []
            for i,s in enumerate(sim_names):
                weight = sim_minmaxed[i]
                row = data[data['key'] == s]
                priority.append(row['PRIORITY'])
                features = features.append(row[factors] * weight)
            prop_blocker = 0
            prop_critical = 0
            prop_trivial = 0
            prop_minor = 0

            i = 0

            for s in priority:
                val = s.values[0]
                if val == 1:
                    prop_blocker += sim_minmaxed[i]
                elif val == 2:
                    prop_critical += sim_minmaxed[i]
                elif val == 4:
                    prop_minor += sim_minmaxed[i]
                elif val == 5:
                    prop_trivial += sim_minmaxed[i]
                i+=1
            sum_sim_minaxed = np.sum(sim_minmaxed) if len(sim_minmaxed)>1 else 1
            if sum_sim_minaxed == 0:
                sum_sim_minaxed = 1
            prop_blocker /= sum_sim_minaxed
            prop_critical /= sum_sim_minaxed
            prop_minor /= sum_sim_minaxed
            prop_trivial /= sum_sim_minaxed

            features = features.mean()


            considered_row = data[data['key'] == key]
            for f in factors:
                try:
                    considered_row['sim_' + f] = features[f]
                except:
                    considered_row['sim_' + f] = 0

            considered_row['sim_PROP_BLOCKER'] = prop_blocker
            considered_row['sim_PROP_SEVERE'] = prop_critical
            considered_row['sim_PROP_MINOR'] = prop_minor
            considered_row['sim_PROP_TRIVIAL'] = prop_trivial

            del considered_row['comments']
            del considered_row['title']
            del considered_row['desc']
            new_res = new_res.append(considered_row, ignore_index=True)
        except Exception as e:
            print(e)
    new_res.to_csv(new_res_path, index=False)


def extend_prj_top_k_metric(cross, type, k):

    cores = multiprocessing.cpu_count()
    pool = multiprocessing.Pool(processes=5)
    if not cross:
        input_list = []
        # do_extend_prj_top_k_metric({
        #     "project": 'Camel',
        #     "project_path_name": 'camel'
        # }, type, k)
        for prj in prjs:
            input_list.append([prj, type, k])
        pool.starmap(do_extend_prj_top_k_metric, input_list)
    else:
        do_extend_prj_top_k_metric_cross(type, k)

    # do_extend_prj_top_k_metric(prjs[1])


if __name__ == '__main__':
    rep_time_path = 'H:\\reports\\defect2\\rep_time.pk'

    report_time = {
        }
    for IR in session.query(JiraIssueReport).filter_by(type='Bug').all():

        report_time[IR.key] = {
            'created_at': IR.created,
            'resolved_at': IR.resolved,
            'updated_at': IR.updated,
        }
    with open(rep_time_path,'wb') as f1:
        pickle.dump
        extract_prj(report_time, f1)

    cores = multiprocessing.cpu_count()
    pool = multiprocessing.Pool(processes=cores)
    pool.map(process_prj, prjs)
    extract_dev()
    extract_prj()
    extend_prj()
    integrate('res_')


    for k in [5,10,15,20]:
        top_k_similar('lsi',k)
        extend_prj_top_k_metric(False,'lsi',k)
        integrate('mean_sim_','lsi',k)
        add_date('lsi',k)

        top_k_similar_cross('lsi',k)
        extend_prj_top_k_metric(True,'lsi',k)

    export_dataset()

